package com.example.app.inquiry;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/**
 * @author ryo
 * コントローラークラス
 */
@Controller
public class InquiryController {
	/**
	 * @お問い合わせフォーム画面メソッド
	 * @param model 
	 * @return htmlファイルパス
	 */
	@RequestMapping(value = "inquiry/form", method = RequestMethod.GET)
	public String form(@ModelAttribute InquiryForm form, Model model, ModelAndView mav) {
		
		mav.addObject("form", new InquiryForm());
		
		//form.htmlに画面遷移
		return "inquiry/form";
	}

	/**
	 * お問い合わせ確認画面メソッド
	 * @param model 
	 * @return htmlファイルパス
	 */
	@RequestMapping(value = "inquiry/confirm", method = RequestMethod.POST)
	public String confirm(
			@ModelAttribute @Validated
			@RequestParam("name") String name, 
			@RequestParam("email") String email, 
			@RequestParam("comment") String comment, 
			InquiryForm form, BindingResult error, Model model, ModelAndView mav) {
		
		mav.addObject("form", new InquiryForm());
		
		form.setname(name);
		form.setemail(email);
		form.setcomment(comment);
		
		
		//入力チェックに引っかかった場合、メッセージを表示してform画面に戻る
		if (error.hasErrors()) {
			/*
			List<String> errorList = new ArrayList<String>();
			for(ObjectError objecterror : error.getAllErrors()) {
				errorList.add(objecterror.getDefaultMessage());
				model.addAttribute("validationError", errorList);
			}
			*/
			return form(form, model, mav);
			
		}
		
		model.addAttribute("name", form.getname());
		model.addAttribute("email", form.getemail());
		model.addAttribute("comment", form.getcomment());
		
		return "inquiry/confirm";

	}

	//戻るメソッド
	//値を返す時はURLにセットする値を含めてあげる。
	@RequestMapping(value = "inquiry/back", method = RequestMethod.POST)
	public String back(@ModelAttribute InquiryForm form, Model model) {

		model.addAttribute("name", form.getname());
		model.addAttribute("email", form.getemail());
		model.addAttribute("comment", form.getcomment());
		
		//form.htmlに画面遷移
		return "inquiry/form";
	}

	//完了メソッド
	@RequestMapping(value = "inquiry/complete", method = RequestMethod.POST)
	public String complete(@ModelAttribute InquiryForm form, Model model, RedirectAttributes redirectAttributes) {

		//フラッシュメッセージの設定
		redirectAttributes.addFlashAttribute("flashSuccessMsg", "登録が完了しました");
		
		//form.htmlに画面遷移
		return "inquiry/form";

	}

}
