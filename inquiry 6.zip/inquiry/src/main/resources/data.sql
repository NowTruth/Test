INSERT INTO inquiry (name, email, contents, created)
VALUES ('田中', 'sample1@example.com', 'おはようございます', '2021-09-01 09:00:00');
INSERT INTO inquiry (name, email, contents, created)
VALUES ('鈴木', 'sample2@example.com', 'こんにちは', '2021-09-02 09:00:00');
INSERT INTO inquiry (name, email, contents, created)
VALUES ('佐藤', 'sample3@example.com', 'こんばんは', '2021-09-03 09:00:00');