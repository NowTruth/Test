package com.example.app.inquiry.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.app.inquiry.entity.Inquiry;

/**
 * Daoクラス
 * @author ryo
 */
@Repository
public class InquiryDaoImpl implements InquiryDao {
	
	private DataSource dataSource = null;
	
	// JdbcTemplateのインスタンス生成。
	@Autowired
	JdbcTemplate jdbc;
	
	/**
	 *データ取得メソッド
	 *return List
	 */
	public List<Inquiry> getAll() {
		
		final String sql = "SELECT id, name, email, contents, created FROM inquiry";
		
		// map→keyとvalueの組み合わせ。それをListで受け取る。
        List<Map<String, Object>> getList = jdbc.queryForList(sql);

        // 結果返却用の変数
        List<Inquiry> inquiryList = new ArrayList<>();

        // 取得したデータを結果返却用のListに格納していく
        for (Map<String, Object> map : getList) {

            //Inquiryインスタンスの生成
            Inquiry inquiry = new Inquiry();

            // Inquiryインスタンスに取得したデータをセットする
            inquiry.setId((Integer) map.get("id"));
            inquiry.setName((String) map.get("name")); 
            inquiry.setEmail((String) map.get("email")); 
            inquiry.setContents((String) map.get("contents")); 
            inquiry.setCreated((String) map.get("created")); 

            //結果返却用のListに追加
            inquiryList.add(inquiry);
        }
        return inquiryList;
		
	}
	
	
	public void insertInquiry(Inquiry inquiry) {
		
		final String sql = "insert into inquiry(name, email, contents) values(?, ?, ?)";
        JdbcTemplate jt = new JdbcTemplate(this.dataSource);
        jt.update(sql, new Object[]{inquiry.getName(),
                                    inquiry.getEmail(), inquiry.getContents()});
		
	}
	
}
