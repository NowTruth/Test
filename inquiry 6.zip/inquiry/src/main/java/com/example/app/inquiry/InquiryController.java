package com.example.app.inquiry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.app.inquiry.entity.Inquiry;
import com.example.app.inquiry.service.InquiryServiceImpl;

/**
 * @author ryo
 * コントローラークラス
 */
@Controller
public class InquiryController {
	
	/**
	 * @お問い合わせフォーム画面メソッド
	 * @param model 
	 * @return htmlファイルパス
	 */
	@RequestMapping(value = "inquiry/form", method = RequestMethod.GET)
	public String form(InquiryForm inquiryForm, Model model) {

		//form.htmlに画面遷移
		return "inquiry/form";
	}

	/**
	 * お問い合わせ確認画面メソッド
	 * @param model 
	 * @return htmlファイルパス
	 */
	@RequestMapping(value = "inquiry/confirm", method = RequestMethod.POST)
	public String confirm(@Validated InquiryForm inquiryForm, BindingResult error, Model model) {

		//入力チェックに引っかかった場合、メッセージを表示してform画面に戻る
		if (error.hasErrors()) {
			return "inquiry/form";
		}
		
		//confirm.htmlに画面遷移
		return "inquiry/confirm";

	}

	//戻るメソッド
	//値を返す時はURLにセットする値を含めてあげる。
	@RequestMapping(value = "inquiry/form", method = RequestMethod.POST)
	public String back(InquiryForm form, Model model) {
		//form.htmlに画面遷移
		return "inquiry/form";
	}

	//完了メソッド
	@RequestMapping(value = "inquiry/complete", method = RequestMethod.POST)
	public String complete(@Validated InquiryForm form, Model model, BindingResult error, RedirectAttributes redirectAttributes) {
		
		//入力チェックに引っかかった場合、メッセージを表示してform画面に戻る
		if (error.hasErrors()) {
			return "inquiry/form";
		}
		
		//フラッシュメッセージの設定
		redirectAttributes.addFlashAttribute("flashSuccessMsg", "登録が完了しました");

		//form.htmlに画面遷移
		return "redirect:/inquiry/form";

	}
	
	@Autowired
      InquiryServiceImpl service;
	
	//データを追加する
	@RequestMapping(value = "inquiry/insert", method = RequestMethod.GET)
	public void insert(@ModelAttribute Inquiry inquiry, Model model) {
		
		service.save(inquiry);
			
	}
	
	@RequestMapping(value = "inquiry/index", method = RequestMethod.GET)
	public String form(Inquiry inquiry, Model model) {
		
		service.getAll();
		
		model.addAttribute("id", inquiry.getId());
		model.addAttribute("name", inquiry.getName());
		model.addAttribute("email", inquiry.getEmail());
		model.addAttribute("contents", inquiry.getContents());
		model.addAttribute("created", inquiry.getCreated());
		
		//form.htmlに画面遷移
		return "inquiry/index";
	}
	
	

}
