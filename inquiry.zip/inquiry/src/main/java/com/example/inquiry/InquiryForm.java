package com.example.inquiry;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

/**
 * @author ryo
 * フォームクラス
 */
public class InquiryForm {

	//必須入力
	@NotBlank(message = "氏名を入力してください")
	@NotNull(message = "nullは許可されていません")
	@Length(min=1, max=20, message = "1~20文字で入力してください")
	public String name;
	
	//必須入力、メールアドレス形式
	@NotBlank(message = "emailを入力してください")
	@NotNull(message = "nullは許可されていません")
	@Email(message = "email形式で入力してください")
	private String email;
	
	//必須入力
	@NotBlank(message = "内容を入力してください")
	@NotNull(message = "nullは許可されていません")
	private String comment;
	
	
	/**
	 * コンストラクタ
	 */
	public InquiryForm(String name, String email, String comment) {
		setname(name);
		setemail(email);
		setcomment(comment);
	}

	/**
	 * 氏名書き換えメソッド
	 * @param name 氏名
	 */
	public void setname(String name) {
		this.name = name;
	}

	/**
	 * メールアドレス書き換えメソッド
	 * @param email　メールアドレス
	 */
	public void setemail(String email) {
		this.email = email;
	}

	/**
	 * 内容書き換えメソッド
	 * @param comment　内容
	 */
	public void setcomment(String comment) {
		this.comment = comment;
	}

	/**
	 * 氏名取得メソッド
	 * @return　String 氏名
	 */
	public String getname() {
		return name;
	}

	/**
	 * メールアドレス取得メソッド
	 * @return　String メールアドレス
	 */
	public String getemail() {
		return email;
	}

	/**
	 * 内容取得メソッド
	 * @return String 内容
	 */
	public String getcomment() {
		return comment;
	}

}
