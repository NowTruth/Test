package com.example.inquiry;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * @author ryo
 * コントローラークラス
 */
@Controller
public class InquiryController {
	/**
	 * @お問い合わせフォーム画面メソッド
	 * @param model 
	 * @return htmlファイルパス
	 */
	@RequestMapping(value = "inquiry/form", method = RequestMethod.GET)
	public String form(InquiryForm form, Model model) {
		//form.htmlに画面遷移
		return "inquiry/form";
	}

	/**
	 * お問い合わせ確認画面メソッド
	 * @param model 
	 * @return htmlファイルパス
	 */
	@PostMapping(value = "inquiry/confirm", params = "confirm")
	public String confirm(@RequestParam("name") String name, 
			@RequestParam("email") String email, 
			@RequestParam("comment") String comment, 
			@ModelAttribute @Validated
			InquiryForm form, BindingResult error, Model model) {
		
		//BindingResult error
		//HttpServletRequest request
		
		//インスタンス生成
		//フォーム画面で入力した値を変数にセット
		InquiryForm inq = new InquiryForm(name, email, comment);
		
		//入力内容に問題ない場合,confirm.htmlに画面遷移する
		//モデルへの登録
		model.addAttribute("name", inq.getname());
		model.addAttribute("email", inq.getemail());
		model.addAttribute("comment", inq.getcomment());

		//入力チェックに引っかかった場合、メッセージを表示してform画面に戻る
		if (error.hasErrors()) {

			//GETリクエスト用のメソッドを呼び出して、form.html画面に戻る
			return form(form, model);
		}
	
		return "inquiry/confirm";

	}

	//戻るメソッド
	//値を返す時はURLにセットする値を含めてあげる。
	@PostMapping(value = "inquiry/form", params = "back")
	public String back(InquiryForm form, Model model) {

		//String name = request.getParameter("name");
	//	String email = request.getParameter("email");
	//	String comment = request.getParameter("comment");

		//form.htmlに画面遷移
		return "inquiry/form";
	}

	//完了メソッド
	@PostMapping(value = "inquiry/complete", params = "complete")
	public String complete(InquiryForm form, Model model, RedirectAttributes redirectAttributes) {

		//フラッシュメッセージの設定
		redirectAttributes.addFlashAttribute("flashSuccessMsg", "登録が完了しました");
		model.addAttribute("flashSuccessMsg", "登録が完了しました");
		//form.htmlに画面遷移
		return "inquiry/form";

	}

}
