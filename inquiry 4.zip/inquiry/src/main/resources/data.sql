INSERT INTO inquiry 
(name, email, contents, created)
VALUES(,,,now())
;