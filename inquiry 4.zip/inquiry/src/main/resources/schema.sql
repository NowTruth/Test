CREATE TABLE inquiry　NOT EXISTS inquirydb(
 id int PRIMARY KEY AUTO_INCREMENT, 
 name VARCHAR(20) NOT NULL, 
 email VARCHAR() NOT NULL IS ((Like "*?@?*.?*") AND (Not Like "*[ ,;]*")),
 contents VARCHAR() NOT NULL, 
 created DATE(YYYY-MM-DD HH:MM:SS)
);

INSERT INTO inwuiry
(name, email, contents, created)
VALUES
('田中一郎', 'ichiro.tanaka@sample.com', 'テストデータ', now()),
('佐藤二郎', 'jiro.sato@sample.com', 'テストデータ', now()),
('中村三郎', 'saburo.nakamura@sample.com', 'テストデータ', now());


CREATE TABLE survey　NOT EXISTS surveydb(
 id INT PRIMARY KEY AUTO_INCREMENT, 
 age INT NOT NULL, 
 satisfaction INT NOT NULL,
 contents VARCHAR() NOT NULL, 
 created DATE(YYYY-MM-DD HH:MM:SS)
);