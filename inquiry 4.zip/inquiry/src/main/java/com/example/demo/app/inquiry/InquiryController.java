package com.example.demo.app.inquiry;

import org.springframework.stereotype.Controller;

/**
 * @author ryo
 * コントローラクラス
 *
 */
@Controller
public class InquiryController {
	
	
}
