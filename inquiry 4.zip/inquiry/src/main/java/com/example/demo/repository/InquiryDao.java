package com.example.demo.repository;

public class InquiryDao {
	
	public String insertInquiry() {
		
	}
	
	public String getAll() {
		
	}
}
