package com.example.demo.service;

public class InquiryService {
	
    public String save() {
		
	}
	
	public String getAll() {
		
	}

}
