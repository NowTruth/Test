package com.example.demo.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//インターフェースをオーバーライドする

public class InquiryDaoImpl implements InquiryDao {
	
	private final static String DRIVER_URL="jdbc:h2:mem:test";
    private final static String DRIVER_NAME="org.h2.Driver";
    private final static String USER_NAME="sa";
    private final static String PASSWORD="";


    public Connection createConnection(){
    try{
        Class.forName(DRIVER_NAME);
        Connection con=DriverManager.getConnection(DRIVER_URL,USER_NAME,PASSWORD);
        return con;
        }catch(ClassNotFoundException e){
            System.out.println("Can't Find H2 Driver.\n");
            }catch(SQLException e){
                 System.out.println("Connection Error.\n");
                }
                return null;
        }

    public void closeConnection(Connection con){
        try{
            con.close();
        }catch(Exception ex){}
    }

	
	public void insertInquiry(String name, String email, String contents, String created){
		Connection con = null;
        con = createConnection();
        try{
            String sql="insert into inquiry values (?,?,?, ?);";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, contents);
            stmt.setString(4, created);

            stmt.executeUpdate();

            stmt.close();
            con = null;

        }catch(SQLException e){

        }finally{

        }
	}
	
}
