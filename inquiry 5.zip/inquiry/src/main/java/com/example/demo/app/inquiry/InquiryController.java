package com.example.demo.app.inquiry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Inquiry;
import com.example.demo.service.InquiryService;
/**
 * @author ryo
 * コントローラクラス
 *
 */
@RestController
public class InquiryController {
	
	public String name;
	public String email;
	public String contents;
	public String created;
	
	List<Inquiry> inquiry = new ArrayList<Inquiry>();
	
	inquiry.add(new Inquiry(name, email, contents, created));
	
	model.addAttribute("Inquiry", inquiry);
	
	@Autowired
    private InquiryService inquiryServicelmpl;

    @GetMapping(path = "/inquiryget")
    public List<Inquiry> getAll() {
        return inquiryServicelmpl.getAll();
    }

    @PostMapping(path = "/inquirysave")
    public int insert(@RequestBody Inquiry inquiry) {
        return inquiryServicelmpl.save();
    }
	
	
	@RequestMapping(value = "/inquiry", method = RequestMethod.GET)
	public String form(Inquiry inquiry, Model model) {

		//form.htmlに画面遷移
		return "inquiry/index";
	}
	
	
}
