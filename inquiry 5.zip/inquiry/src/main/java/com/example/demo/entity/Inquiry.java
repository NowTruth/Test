package com.example.demo.entity;

import org.seasar.Entity;
import org.seasar.doma.GeneratedValue;
import org.seasar.doma.GenerationType;
import org.seasar.doma.Id;


@Entity
public class Inquiry {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String name;
	private String email;
	private String contents;
	private String created;
	
	public Inquiry() {
		super();
	}
	
	public Inquiry(Integer id, String name, String email, String contents, String created) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.contents = contents;
		this.created = created;
	}
	
	
	public Integer getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getContents() {
		return contents;
	}

	public String getCreated() {
		return created;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public void setCreated(String created) {
		this.created = created;
	}
	
	

}
