package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.Inquiry;
import com.example.demo.repository.InquiryDao;

public class InquiryServiceImpl implements InquiryService {
	
	
	 @Autowired
	    InquiryDao dao;

	    public List<Inquiry> getAll() {
	        return dao.getAll();
	    }
	
	
   public void save() {
   	InquiryDao.insertInquiry();
	}

}
