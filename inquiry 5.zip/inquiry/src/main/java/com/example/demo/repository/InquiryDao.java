package com.example.demo.repository;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Inquiry;

@ConfigAutowireable
@Dao
public interface InquiryDao {
	
	  @Select
	    List<Inquiry> getAll();
	  
	  @Insert
	  @Transactional
	  public  String insertInquiry(Inquiry inquiry) ;
	
}
